n = int(input("Enter number of elements: "))
arr = list(map(int, input(f"Enter {n} elements: ").split()))
arr = [arr[-1]] + arr[:-1]
print("Array after rotation:", *arr)