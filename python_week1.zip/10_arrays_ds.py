n = int(input("Enter number of elements: "))
arr = list(map(int, input(f"Enter {n} elements: ").split()))
print("Reversed array:", *arr[::-1])