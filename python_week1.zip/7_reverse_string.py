s = input("Enter a string: ")
print("Reversed string:", s[::-1])