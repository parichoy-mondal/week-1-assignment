from collections import Counter
n = int(input("Enter number of elements: "))
arr = list(map(int, input(f"Enter {n} elements: ").split()))
freq = Counter(arr)
print("Element Frequency")
for k, v in freq.items():
    print(k, "     ", v)