n = int(input("Enter number of elements: "))
arr = list(map(int, input(f"Enter {n} elements: ").split()))
result = [x for x in arr if x != 0] + [0] * arr.count(0)
print("Array after moving zeros to end:", *result)