n = int(input("Enter number of elements: "))
arr = list(map(int, input(f"Enter {n} elements: ").split()))
print("Largest element:", max(arr))